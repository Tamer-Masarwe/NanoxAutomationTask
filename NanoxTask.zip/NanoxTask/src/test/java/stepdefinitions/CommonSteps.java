package stepdefinitions;

import com.demoblaze.utils.AssertUtility;
import com.demoblaze.utils.LoggerUtility;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.openqa.selenium.Alert;

public class CommonSteps extends BaseStepDefinition
{
    String productName;

    @Given("the user is on the homepage")
    public void the_user_is_on_the_homepage()
    {
        OpenWeb();
        homePage.header.clickHome();

        AssertUtility.assertTrue(homePage.isHomePageOpened(),
                "The home page is opened",
                "The home page is not opened");
    }

    @And("the user clicks the Add to cart button")
    public void the_user_clicks_the_add_to_cart_button()
    {
        productPage.clickAddToCartButton();
        LoggerUtility.info("Clicked the Add to cart button");
    }

    @And("the user accepts the alert button")
    public void the_user_accepts_the_alert_button() {
        Alert alert = swtichToAlert();

        AssertUtility.assertTrue(alert.getText().toLowerCase().contains("product added"),
                "The product is added to the cart",
                "The product is not added to the cart");
        alert.accept();
    }

    @And("the user clicks on cart button")
    public void the_user_clicks_on_cart_button()
    {
        homePage.header.clickCart();
    }
}
