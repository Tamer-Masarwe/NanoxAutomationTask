package stepdefinitions;

import com.demoblaze.utils.AssertUtility;
import io.cucumber.java.en.*;

public class PlaceOrderSteps extends BaseStepDefinition
{
    @When("the user clicks on place order button")
    public void the_user_clicks_on_place_order_button() {
        cartPage.clickPlaceOrderButton();

        AssertUtility.assertTrue(placeOrderModal.isModalDisplayed(),
                "The place older modal is opened",
                "The place older modal is not opened");
    }

    @When("the user fills the fields")
    public void the_user_fills_the_fields()
    {
        placeOrderModal.fillForm("full Name", "Israel", "Tel Aviv", "123456789", "4", "2025");
    }

    @When("the user clicks purchase button")
    public void the_user_clicks_purchase_button() {
        placeOrderModal.clickPurchaseButton();
    }

    @Then("the purchase done successfully")
    public void the_purchase_done_successfully()
    {
        AssertUtility.assertTrue(placeOrderModal.isConfirmationDisplayed(),
                "The purchase is finished successfully",
                "The purchase is not finished successfully");
    }

}
