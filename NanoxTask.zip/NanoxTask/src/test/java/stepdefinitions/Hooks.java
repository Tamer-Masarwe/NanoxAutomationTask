package stepdefinitions;

import com.demoblaze.utils.LoggerUtility;
import com.demoblaze.utils.WebDriverUtility;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Hooks
{
    @Before
    public void setUp(Scenario scenario)
    {
        LoggerUtility.info("The scenario >> " + scenario.getName() + " is starting up");
        WebDriverUtility.getDriver();
    }

    @After
    public void tearDown(Scenario scenario)
    {
        TakeScreenshot(scenario);
        WebDriverUtility.quitDriver();
        LoggerUtility.info("The scenario >> " + scenario.getName() + " is shutting down");
    }

    private void TakeScreenshot(Scenario scenario)
    {
        if (scenario.isFailed())
        {
            TakesScreenshot ts = (TakesScreenshot) WebDriverUtility.getDriver();
            File srcFile = ts.getScreenshotAs(OutputType.FILE);

            // Format filename with timestamp and scenario name
            String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String filename = "screenshots/" + scenario.getName().replaceAll(" ", "_") + "_" + time + ".png";

            try {
                Files.createDirectories(Paths.get("screenshots")); // Create folder if not exist
                Files.copy(srcFile.toPath(), Paths.get(filename));
                System.out.println("📸 Screenshot saved: " + filename);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
