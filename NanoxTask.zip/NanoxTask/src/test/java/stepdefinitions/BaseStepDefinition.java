package stepdefinitions;

import com.demoblaze.Modals.LoginModal;
import com.demoblaze.Modals.PlaceOrderModal;
import com.demoblaze.Modals.SignupModal;
import com.demoblaze.pages.*;
import com.demoblaze.utils.WebDriverUtility;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseStepDefinition
{
    private WebDriver driver;
    protected HomePage homePage;
    protected LoginModal loginModal;
    protected SignupModal signupModal;
    protected ProductPage productPage;
    protected CartPage cartPage;
    protected PlaceOrderModal placeOrderModal;

    public BaseStepDefinition()
    {
        driver = WebDriverUtility.getDriver();
        homePage = new HomePage(driver);
        loginModal = new LoginModal(driver);
        signupModal = new SignupModal(driver);
        productPage = new ProductPage(driver);
        cartPage = new CartPage(driver);
        placeOrderModal = new PlaceOrderModal(driver);
    }

    public void OpenWeb()
    {
        WebDriverUtility.OpenBrowser();
    }

    public Alert swtichToAlert()
    {
        WebDriverWait wait = WebDriverUtility.getWait();
        return wait.until(ExpectedConditions.alertIsPresent());
    }
}
