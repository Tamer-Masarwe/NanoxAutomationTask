package stepdefinitions;

import com.demoblaze.utils.AssertUtility;
import io.cucumber.java.en.*;

public class LoginSteps extends BaseStepDefinition
{

    @When("the user clicks on the Log in button")
    public void the_user_clicks_on_the_button()
    {
        homePage.header.clickLogin();

        AssertUtility.assertTrue(loginModal.isLoginWindowDisplayed(),
                "The login window is opened",
                "The login window is not opened");
    }

    @When("the user enters username {string} and password {string}")
    public void the_user_enters_username_and_password(String username, String password)
    {
        loginModal.enterUsername(username);
        loginModal.enterPassword(password);
    }

    @When("the user clicks the submit button")
    public void the_user_clicks_the_submit_button()
    {
        loginModal.clickLoginButton();
    }

    @Then("the user logged in and should see {string}")
    public void the_user_logged_in_and_should_see(String welcomeText)
    {
        String actualWelcomeMessage = homePage.header.getWelcomeText();

        AssertUtility.assertEquals(actualWelcomeMessage, welcomeText,
                "The user logged in successfully",
                "The user failed to log in");
    }
}
