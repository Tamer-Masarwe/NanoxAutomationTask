package stepdefinitions;

import com.demoblaze.utils.AssertUtility;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class DeleteItemSteps extends BaseStepDefinition
{
    @And("the user clicks the delete button")
    public void the_user_clicks_the_delete_button()
    {
        cartPage.deleteFirstItemInCart();
    }

    @Then("the item is removed from the cart")
    public void the_item_is_removed_from_the_cart()
    {
        AssertUtility.assertTrue(cartPage.isCartEmpty(),
                "The product  is deleted from the cart",
                "The product is not deleted from the cart");
    }
}
