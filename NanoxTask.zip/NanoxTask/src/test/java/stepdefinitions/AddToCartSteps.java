package stepdefinitions;

import com.demoblaze.utils.AssertUtility;
import io.cucumber.java.en.*;


public class AddToCartSteps extends BaseStepDefinition
{
    String productName;

    @When("the user selects a product")
    public void the_user_selects_a_product()
    {
        productName = homePage.productsComponent.selectAProduct();

        AssertUtility.assertEquals(productPage.getProductTitle(), productName,
                "The product page of the selected product " + productName + " is opened",
                "The product page of the selected product " + productName + " was not opened");
    }

    @Then("the item is added to the cart")
    public void the_item_is_added_to_the_cart()
    {
        AssertUtility.assertTrue(cartPage.isProductExistsInCart(productName),
                "The product " + productName + " is added to the cart",
                 "The product " + productName + " is not added to the cart");
    }
}
