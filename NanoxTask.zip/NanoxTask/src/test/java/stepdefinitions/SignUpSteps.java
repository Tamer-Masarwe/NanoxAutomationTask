package stepdefinitions;

import com.demoblaze.utils.AssertUtility;
import io.cucumber.java.en.*;
import org.openqa.selenium.Alert;

import java.util.UUID;

public class SignUpSteps extends BaseStepDefinition
{

    @When("the user clicks on the Sign up button")
    public void the_user_clicks_on_the_sign_up_button()
    {
        homePage.header.clickSignup();

        AssertUtility.assertTrue(signupModal.isSignUpWindowDisplayed(),
                "The signup window is opened",
                "The signup window is not opened");
    }

    @And("the user enters random username and password")
    public void the_user_enters_random_username_and_password()
    {
        String randomString = "user" + UUID.randomUUID().toString().substring(0, 5);
        signupModal.enterUsername(randomString);
        signupModal.enterPassword(randomString);
    }

    @And("the user clicks the sign up button")
    public void the_user_clicks_the_sign_up_button()
    {
        signupModal.clickSignupButton();
    }

    @Then("the user signed up successfully")
    public void the_user_signed_up_successfully()
    {
        Alert alert = swtichToAlert();
        String alertText = alert.getText();
        alert.accept();

        AssertUtility.assertTrue(alertText.toLowerCase().contains("sign up successful"),
                "The new user signed up successfully",
                "The new user sign up failed");
    }
}
