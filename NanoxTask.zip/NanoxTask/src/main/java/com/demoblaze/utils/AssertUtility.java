package com.demoblaze.utils;

import org.testng.Assert;

public class AssertUtility
{
    public static void assertTrue(boolean condition, String passMessage, String failMessage)
    {
        try
        {
            Assert.assertTrue(condition, failMessage);
            LoggerUtility.info(passMessage);
        } catch (AssertionError e)
        {
            LoggerUtility.error("Assertion failed: " + failMessage, e);
            throw e;
        }
    }

    public static void assertFalse(boolean condition, String passMessage, String failMessage)
    {
        try
        {
            Assert.assertFalse(condition, failMessage);
            LoggerUtility.info(passMessage);
        } catch (AssertionError e) {
            LoggerUtility.error("Assertion failed: " + failMessage, e);
            throw e;
        }
    }

    public static void assertEquals(Object actual, Object expected, String passMessage, String failMessage)
    {
        try
        {
            Assert.assertEquals(actual, expected, failMessage);
            LoggerUtility.info(passMessage);
        } catch (AssertionError e) {
            LoggerUtility.error("Assertion failed: " + failMessage, e);
            throw e;
        }
    }
}