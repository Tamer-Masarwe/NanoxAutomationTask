package com.demoblaze.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class WebDriverUtility
{
    private static WebDriver driver;

    public static WebDriver getDriver() {
        if (driver == null)
        {
            System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            driver.manage().window().maximize();
            LoggerUtility.info("Browser launched successfully");
        }
        return driver;
    }

    public static WebDriverWait getWait() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        return wait;
    }

    public static void OpenBrowser()
    {
        getDriver().get("http://demoblaze.com/index.html");
        LoggerUtility.info("Browser opened successfully");
    }

    public static void quitDriver(){

        if (driver != null)
        {
            driver.quit();
            driver = null;
            LoggerUtility.info("Browser closed");
        }
    }
}
