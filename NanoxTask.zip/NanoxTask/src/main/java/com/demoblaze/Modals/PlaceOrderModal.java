package com.demoblaze.Modals;

import com.demoblaze.utils.WebDriverUtility;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PlaceOrderModal
{
    private WebDriver driver;

    @FindBy(id = "orderModalLabel")
    private WebElement modalTitle;

    @FindBy(id = "name")
    private WebElement nameField;

    @FindBy(id = "country")
    private WebElement countryField;

    @FindBy(id = "city")
    private WebElement cityField;

    @FindBy(id = "card")
    private WebElement creditCardField;

    @FindBy(id = "month")
    private WebElement monthField;

    @FindBy(id = "year")
    private WebElement yearField;

    @FindBy(xpath = "//button[text()=\"Purchase\"]")
    private WebElement purchaseButton;

    @FindBy(xpath = "//*[text()=\"Thank you for your purchase!\"]")
    private WebElement purchaseConfirmationMessage;


    public PlaceOrderModal(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void putNameField(String name){
        nameField.clear();
        nameField.sendKeys(name);
    }

    public void putCountryField(String country){
        countryField.clear();
        countryField.sendKeys(country);
    }
    public void putCityField(String city){
        cityField.clear();
        cityField.sendKeys(city);
    }
    public void putCreditCardField(String creditCard){
        creditCardField.clear();
        creditCardField.sendKeys(creditCard);
    }
    public void putMonthField(String month){
        monthField.clear();
        monthField.sendKeys(month);
    }
    public void putYearField(String year){
        monthField.clear();
        monthField.sendKeys(year);
    }
    public void fillForm(String name, String country, String city, String creditCard, String month, String year) {
        putNameField(name);
        putCountryField(country);
        putCityField(city);
        putCreditCardField(creditCard);
        putMonthField(month);
        putYearField(year);
    }

    public void clickPurchaseButton()
    {
        purchaseButton.click();
    }

    public boolean isConfirmationDisplayed()
    {
        return purchaseConfirmationMessage.isDisplayed();
    }

    public boolean isModalDisplayed()
    {
        WebDriverWait wait = WebDriverUtility.getWait();
        wait.until(ExpectedConditions.visibilityOf(modalTitle));
        return modalTitle.isDisplayed();
    }
}
