package com.demoblaze.Modals;

import com.demoblaze.utils.LoggerUtility;
import com.demoblaze.utils.WebDriverUtility;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignupModal
{
    private WebDriver driver;

    @FindBy(id = "sign-username")
    private WebElement usernameField;

    @FindBy(id = "sign-password")
    private WebElement passwordField;

    @FindBy(xpath = "//button[text()='Sign up']")
    private WebElement signupButton;

    public SignupModal(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void signUp(String username, String password)
    {
        enterUsername(username);
        enterPassword(password);
        clickSignupButton();
    }

    public void enterUsername(String username)
    {
        usernameField.clear();
        usernameField.sendKeys(username);
        LoggerUtility.info("Entered Username: " + username);
    }

    public void enterPassword(String password)
    {
        passwordField.clear();
        passwordField.sendKeys(password);
        LoggerUtility.info("Entered Password: " + password);
    }

    public void clickSignupButton() {
        signupButton.click();
        LoggerUtility.info("Clicked signup Button");
    }

    public boolean isSignUpWindowDisplayed()
    {
        WebDriverWait wait = WebDriverUtility.getWait();
        WebElement windowTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("signInModalLabel")));
        return windowTitle.isDisplayed();
    }
}
