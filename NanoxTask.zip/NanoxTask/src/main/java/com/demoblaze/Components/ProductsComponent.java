package com.demoblaze.Components;

import com.demoblaze.utils.LoggerUtility;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class ProductsComponent
{
    WebDriver driver;
    private List<WebElement> productsList;

    public ProductsComponent(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public String selectAProduct()
    {
        productsList = driver.findElements(By.xpath("//*[@id=\"tbodyid\"]//a[text()]"));
        String productName = productsList.getFirst().getText();
        productsList.getFirst().click();

        LoggerUtility.info("Selected product : " + productName);
        return productName;
    }
}
