package com.demoblaze.Components;

import com.demoblaze.utils.LoggerUtility;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HeaderComponent
{
    WebDriver driver;

    @FindBy(xpath = "//*[@id=\"navbarExample\"]//*[contains(text(), 'Home')]")
    private WebElement homeTab;

    @FindBy(xpath = "//*[@id=\"navbarExample\"]//*[contains(text(), 'Contact')]")
    private WebElement contactTab;

    @FindBy(xpath = "//*[@id=\"navbarExample\"]//*[contains(text(), 'About us')]")
    private WebElement aboutUsTab;

    @FindBy(xpath = "//*[@id=\"navbarExample\"]//*[contains(text(), 'Cart')]")
    private WebElement cartTab;

    @FindBy(xpath = "//*[@id=\"navbarExample\"]//*[contains(text(), 'Log out')]")
    private WebElement logOutTab;

    @FindBy(xpath = "//*[@id=\"navbarExample\"]//*[contains(text(), 'Welcome')]")
    private WebElement welcomeTab;

    @FindBy(xpath = "//*[@id=\"navbarExample\"]//*[contains(text(), 'Log in')]")
    private WebElement logInTab;

    @FindBy(xpath = "//*[@id=\"navbarExample\"]//*[contains(text(), 'Sign up')]")
    private WebElement signUpTab;

    public HeaderComponent(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickLogin() {
        logInTab.click();
        LoggerUtility.info("Clicked Login tab");
    }

    public void clickHome(){
        homeTab.click();
        LoggerUtility.info("Clicked home tab");
    }

    public void clickLogout() {
        logOutTab.click();
        LoggerUtility.info("Clicked logout tab");
    }

    public void clickSignup() {
        signUpTab.click();
        LoggerUtility.info("Clicked Sign up tab");
    }

    public void clickCart() {
        cartTab.click();
        LoggerUtility.info("Clicked Cart tab");
    }

    public String getWelcomeText()
    {
        return welcomeTab.getText();
    }
}
