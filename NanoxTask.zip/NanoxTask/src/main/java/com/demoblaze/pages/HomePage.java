package com.demoblaze.pages;

import com.demoblaze.Components.HeaderComponent;
import com.demoblaze.Components.ProductsComponent;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
public class HomePage
{
    private WebDriver driver;
    public HeaderComponent header;
    public ProductsComponent productsComponent;

    public HomePage(WebDriver driver)
    {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        header = new HeaderComponent(driver);
        productsComponent = new ProductsComponent(driver);
    }

    public boolean isHomePageOpened()
    {
        return driver.getCurrentUrl().contains("index.html");
    }
}


