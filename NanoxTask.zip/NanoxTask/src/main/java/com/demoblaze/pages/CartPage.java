package com.demoblaze.pages;

import com.demoblaze.utils.WebDriverUtility;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CartPage
{
    WebDriver driver;

    @FindBy(xpath = "//button[text()=\"Place Order\"]")
    private WebElement placeOrderButton;

    @FindBy(xpath = "//a[text()=\"Delete\"]")
    private WebElement deleteButton;

    public CartPage(WebDriver driver)
    {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public boolean isProductExistsInCart(String productName)
    {
        WebDriverWait wait = WebDriverUtility.getWait();
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[text()=\"" + productName + "\"]")));
        return element.isDisplayed();
    }

    public void clickPlaceOrderButton()
    {
        placeOrderButton.click();
    }

    public void deleteFirstItemInCart()
    {
        driver.findElements(By.xpath("//a[text()=\"Delete\"]")).getFirst().click();
    }

    public boolean isCartEmpty()
    {
        WebDriverWait wait = WebDriverUtility.getWait();
        By by = By.xpath("//*[@id=\"tbodyid\"]//td");
        return wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
    }
}
