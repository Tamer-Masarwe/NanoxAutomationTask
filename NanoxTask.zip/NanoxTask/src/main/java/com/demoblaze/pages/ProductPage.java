package com.demoblaze.pages;

import com.demoblaze.utils.LoggerUtility;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class ProductPage
{
    private WebDriver driver;

    @FindBy(xpath = "//a[text()=\"Add to cart\"]")
    private WebElement addToCartButton;

    @FindBy(xpath = "//div[@id=\"tbodyid\"]/h2")
    private WebElement productTitle;


    public ProductPage(WebDriver driver)
    {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickAddToCartButton() {
        addToCartButton.click();
        LoggerUtility.info("Clicked add to cart button");
    }

    public String getProductTitle()
    {
        return productTitle.getText();
    }
}
